import QRCode from 'qrcode';
import crypto from 'crypto';

export function generateQRCodeId(): string {
  return crypto.randomBytes(16).toString('hex');
}

export async function generateQRCodeDataURL(data: string): Promise<string> {
  try {
    return await QRCode.toDataURL(data, {
      errorCorrectionLevel: 'H', // Highest error correction for better scanning
      margin: 2, // Increased margin for better scanning
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      },
      width: 512, // Larger size for better scanning
      scale: 8 // Higher scale factor
    });
  } catch (error) {
    throw new Error('Failed to generate QR code');
  }
}

export function createHealthPassportURL(qrCodeId: string): string {
  const baseUrl = process.env.NODE_ENV === 'production' 
    ? process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}` : 'https://your-domain.com'
    : 'http://localhost:5000';
  return `${baseUrl}/passport/${qrCodeId}`;
}