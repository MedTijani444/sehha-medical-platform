#!/bin/bash

# Sehha+ Production Build Script
echo "Building Sehha+ for production deployment..."

# Install dependencies
echo "Installing dependencies..."
npm install

# Build frontend
echo "Building frontend..."
npm run build:client

# Build backend
echo "Building backend..."
npm run build:server

# Create production directory structure
echo "Creating production structure..."
mkdir -p dist/server
mkdir -p dist/client

# Copy built files
echo "Copying built files..."
cp -r client/dist/* dist/client/
cp -r server/dist/* dist/server/
cp package.json dist/
cp -r node_modules dist/

# Create production .env template
echo "Creating environment template..."
cat > dist/.env.example << 'EOF'
# Production Environment Configuration
NODE_ENV=production
PORT=5000

# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/sehha_db

# AI Service Keys
GROQ_API_KEY=your_groq_api_key_here
OPENAI_API_KEY=your_openai_api_key_here

# Email Configuration (Optional)
SMTP_HOST=your_smtp_host
SMTP_PORT=587
SMTP_USER=your_email@domain.com
SMTP_PASS=your_email_password

# Security
SESSION_SECRET=your_very_long_random_session_secret_here
EOF

echo "Production build complete! Files ready in 'dist' directory."
echo "Upload the 'dist' directory to your hosting server."
echo "Don't forget to:"
echo "1. Copy .env.example to .env and configure your settings"
echo "2. Set up your PostgreSQL database"
echo "3. Run 'node server/index.js' to start the application"