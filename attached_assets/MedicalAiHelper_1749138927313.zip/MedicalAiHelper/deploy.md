# Sehha+ Deployment Guide

## Quick Start Deployment

### 1. Upload Files to Your Server
Upload all project files to your hosting server's web directory.

### 2. Install Dependencies
```bash
npm install
```

### 3. Set Environment Variables
Create a `.env` file in your root directory:

```env
# Database Configuration
DATABASE_URL=postgresql://username:password@your-db-host:5432/sehha_db

# AI Service Keys
GROQ_API_KEY=your_groq_api_key
OPENAI_API_KEY=your_openai_api_key

# Server Configuration
NODE_ENV=production
PORT=5000

# Email Configuration (Optional)
SMTP_HOST=your_smtp_host
SMTP_PORT=587
SMTP_USER=your_email@domain.com
SMTP_PASS=your_email_password
```

### 4. Database Setup
If using your own PostgreSQL database:
```bash
# Create database
createdb sehha_db

# Run database migrations
npm run db:push
```

### 5. Build and Start
```bash
# Build the application
npm run build

# Start the server
npm start
```

### 6. Access Your Website
Visit: `http://your-domain.com:5000`

## Server Requirements
- Node.js 18+ 
- PostgreSQL 12+
- 1GB RAM minimum
- SSL certificate (recommended)

## File Structure
```
/your-server-directory/
├── client/          # Frontend React app
├── server/          # Backend Express server
├── shared/          # Shared types and schemas
├── package.json     # Dependencies
├── .env            # Environment variables
└── deploy.md       # This file
```

## Production Checklist
- [ ] Set NODE_ENV=production
- [ ] Configure SSL/HTTPS
- [ ] Set up database backups
- [ ] Configure firewall rules
- [ ] Set up monitoring/logs
- [ ] Test all features work

## Support
Contact: +212 5 22 25 15 45
Email: contact@sehhaplus.com